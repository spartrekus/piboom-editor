

////////////////////////////////////////////////////////////////////////////////////
// Author: Spartrekus
////////////////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////
//////////////////////////////////////////
//////////////////////////////////////////
#include <stdio.h>
#if defined(__linux__)
#define MYOS 1
#elif defined(_WIN32)
#define PATH_MAX 2500
#define MYOS 2
#elif defined(_WIN64)
#define PATH_MAX 2500
#define MYOS 3
#elif defined(__unix__)
#define MYOS 4
#define PATH_MAX 2500
#else
#define MYOS 0
#endif


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>
#include <unistd.h> 
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <dirent.h>
#include <stdlib.h>

#include <ncurses.h>

void quit(void)
{
  endwin();
}


void colornorm(void)
{
    attroff(  A_REVERSE );
    attroff( A_BOLD );
    attroff( A_BLINK );
    attroff( A_UNDERLINE );
    color_set( 7, NULL ); 
}


////////////////////////////////
void nruncmd( char *thecmd   )
{
       char cmdi[PATH_MAX];
       def_prog_mode();
       endwin();
       strncpy( cmdi , "  " , PATH_MAX );
       strncat( cmdi , thecmd , PATH_MAX - strlen( cmdi ) -1 );
       strncat( cmdi , " " , PATH_MAX - strlen( cmdi ) -1 );
       system( cmdi );
       reset_prog_mode();
}




int main(void)
{
  int ch ; 

  initscr();			
  curs_set( 0 );
  start_color();
  init_pair(0, COLOR_BLACK, COLOR_BLACK);
  init_pair(1, COLOR_RED, COLOR_BLACK);
  init_pair(2, COLOR_GREEN, COLOR_BLACK);
  init_pair(3, COLOR_BLUE, COLOR_BLACK);
  init_pair(4, COLOR_YELLOW, COLOR_BLACK);
  init_pair(5, COLOR_CYAN, COLOR_BLACK);
  init_pair(6, COLOR_MAGENTA, COLOR_BLACK);
  init_pair(7, COLOR_WHITE, COLOR_BLACK);
  init_pair(8, COLOR_BLACK, COLOR_YELLOW);

  int x = 5; int i = 1;
  while( 1 )
  {
   erase();
   x = 5; i = 1;
   colornorm(); 
   attroff( A_BOLD );
   color_set( 4 , NULL );
   mvprintw( 3,3, "1: Play " );
   mvprintw( 5,3, "2: Edit " );
   attroff( A_REVERSE );

   color_set( 7, NULL ); mvprintw(  12, 5 , "<Press Key>" );
   refresh();
   ch = getch(); 
   if      ( ch == '1' ) nruncmd( "  make play  "  );
   else if ( ch == '2' ) nruncmd( "  make edit  "  );
  }
  curs_set( 1 );
  endwin();			/* End curses mode		  */
  return(0);
}

